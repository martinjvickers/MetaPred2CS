
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;

public class InputFrame extends JFrame{
	InputPanel panel;
	svm_toy3d ts;

	public InputFrame(svm_toy3d ts){
		super("Input Interface");
		
		this.ts = ts;
		
		panel = new InputPanel(ts);
		
		this.getContentPane().add(panel,BorderLayout.NORTH);
		pack();
	}
}

class InputPanel extends JPanel{
	public final static int WIDTH = 300;
	public final static int RANGE = 100;
	BufferedImage background = null;
	BufferedImage buffer = null;
	private boolean isPressed = false;
	private int dragBtn = -1;
	private int pressedX;
	private int pressedY;
	private int rectLTX = RANGE;
	private int rectLTY = RANGE;
	private int rectWidth = RANGE;
	private int rectHeight = RANGE;
	private int x;
	private int y;
	private int z=0;
	private svm_toy3d ts;
	private Rectangle2D.Float movePane = new Rectangle2D.Float(100,100,100,100);
	private AlphaComposite composite;

	public InputPanel(svm_toy3d ts)
	{
		this.ts = ts;
		composite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.5F);
		this.addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{ mouse_pressed(e); }
			
			public void mouseClicked(MouseEvent e)
			{ mouse_clicked(e); }

			public void mouseReleased(MouseEvent e)
			{ mouse_released(e); }
		});

		this.addMouseMotionListener(new MouseMotionAdapter()
		{
			public void mouseDragged(MouseEvent e)
			{ mouse_dragged(e); }
			
			public void mouseMoved(MouseEvent e)
			{ mouse_moved(e); }
		});

		this.setBorder(BorderFactory.createEmptyBorder(0,0,WIDTH,WIDTH));
	}
	
	public void mouse_pressed(MouseEvent e)
	{
		dragBtn = e.getButton();
		if(e.getButton()==MouseEvent.BUTTON3)
		{
			pressedX = e.getX();
			pressedY = e.getY();
		}
	}
	
	public void mouse_clicked(MouseEvent e)
	{
		if( e.getButton()==MouseEvent.BUTTON1 && movePane.contains( e.getX(),e.getY() ) )
		{
			addPoint(e);
		}
	}
	
	public void mouse_released(MouseEvent e)
	{
		if(e.getButton()==MouseEvent.BUTTON3)
		{
			if ( rectWidth-2*(e.getY()-pressedY) <= RANGE )
			{
				rectLTX = RANGE;
				rectLTY = RANGE;
				rectWidth = RANGE;
				rectHeight = RANGE;
				z = 0;
			}
			else if( rectLTX+(e.getY()-pressedY) <= 0 )
			{
				rectLTX = 0;
				rectLTY = 0;
				rectWidth = WIDTH;
				rectHeight = WIDTH;
				z = RANGE;
			}
			else
			{
				rectLTX = rectLTX+(e.getY()-pressedY);
				rectLTY = rectLTY+(e.getY()-pressedY);
				rectWidth = rectWidth-2*(e.getY()-pressedY);
				rectHeight = rectHeight-2*(e.getY()-pressedY);
				z = ( z-(e.getY()-pressedY) );
			}
		}
	}
	
	public void mouse_dragged(MouseEvent e)
	{
		if(dragBtn==MouseEvent.BUTTON3)
		{
			adjust(e);					
		}
	}
	
	public void mouse_moved(MouseEvent e)
	{
		if( movePane.contains( e.getX(),e.getY() ) )
			mouse_move(e);
	}
	
	public void addPoint(MouseEvent e)
	{
		ts.button_enter_clicked();
	}
	
	public void mouse_move(MouseEvent e)
	{
		ts.setPosStatus( -1 + 2*(e.getX()-movePane.getX())/movePane.getWidth(), 1 + 2*(movePane.getY()-e.getY())/movePane.getHeight(), (z-RANGE/2)/(float)(RANGE/2));
	}

	public void adjust(MouseEvent e)
	{
		Graphics2D g2 = buffer.createGraphics();
		g2.drawImage(background,0,0,this);
		g2.setColor(Color.white);
		g2.fillRect(100,100,100,100);
		
		if ( rectWidth-2*(e.getY()-pressedY) <= RANGE )
		{
			movePane.setRect(RANGE,RANGE,RANGE,RANGE);
			ts.setPosZStatus(-1);
		}
		else if( rectLTX+(e.getY()-pressedY) <= 0 )
		{
			movePane.setRect(0,0,WIDTH,WIDTH);
			ts.setPosZStatus(1);
		}
		else
		{
			movePane.setRect(rectLTX+(e.getY()-pressedY),rectLTY+(e.getY()-pressedY),rectWidth-2*(e.getY()-pressedY),rectHeight-2*(e.getY()-pressedY));
			ts.setPosZStatus( (z-(e.getY()-pressedY)-RANGE/2)/(float)(RANGE/2) );
		}
		g2.setColor(Color.red);
		g2.setComposite(composite);
		g2.fill(movePane);
		repaint();
	}

	public void update(Graphics g)
	{
		paint(g);
	}

	public void paint(Graphics g)
	{
		// create buffer first time
		if(buffer == null)
		{
			//draw background
			background = new BufferedImage(300,300,BufferedImage.TYPE_INT_RGB);
			buffer = new BufferedImage(300,300,BufferedImage.TYPE_INT_RGB);
			Graphics background_g = background.createGraphics();
			background_g.setColor(Color.gray);
			background_g.fillRect(0,0,300,300);
			background_g.setColor(Color.white);
			background_g.drawLine(0,0,300,300);
			background_g.drawLine(0,300,300,0);
			Graphics2D g2 = buffer.createGraphics();
			g2.drawImage(background,0,0,this);
			g2.setColor(Color.white);
			g2.fillRect(RANGE,RANGE,RANGE,RANGE);
			g2.setComposite(composite);
			g2.setColor(Color.red);
			g2.fill(movePane);
		}
		g.drawImage(buffer,0,0,this);
	}
}
