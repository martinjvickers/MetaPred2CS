import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.behaviors.vp.OrbitBehavior;
import com.sun.j3d.utils.geometry.Box;
import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.universe.ViewingPlatform;
import com.sun.j3d.utils.geometry.ColorCube;
import java.applet.Applet;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.media.j3d.*;
import javax.swing.*;
import javax.vecmath.*;
import java.text.*;
import java.util.ArrayList;
import java.util.Locale;
import libsvm.*;//libsvm for svm_toy3d, which we just compiled. 

public class svm_toy3d extends JApplet
{
	static final float coordinate_parameter = 0.7F;
	static final float cube_length = 0.005F;
	static final int max_point = 100;

	private int[][][] surface = new int[max_point][max_point][max_point];
	private InputFrame inputFrame;
	private NumberFormat nf;//How many digits after decimal point
	private Canvas3D canvas3D;
	private SimpleUniverse su;
	private BranchGroup sceneGraph;
	private TransformGroup trg;
	private JTextField xvalue;
	private JTextField yvalue;
	private JTextField zvalue;
	private JTextField input_line;//SVM training parameters
	private byte nowcolor;
	private InputPanel input_panel;

	//point color
	private Color3f colors[] = 
	{
		new Color3f(1.0F, 1.0F, 0.0F), 
		new Color3f(0.0F, 1.0F, 1.0F), 
		new Color3f(1.0F, 0.0F, 1.0F)
	};

	//plane surface color
	private Color3f surf_colors[][] = 
	{{new Color3f(1.0F, 1.0F, 0.0F), 
		 new Color3f(0.0F, 1.0F, 1.0F), 
		 new Color3f(1.0F, 0.0F, 1.0F)},
	{new Color3f(1.0F, 0.0F, 1.0F),
		new Color3f(1.0F, 1.0F, 0.0F), 
		new Color3f(0.0F, 1.0F, 1.0F)}
	};

	//x-y-z axes color
	private Color3f axes_colors[] = 
	{
		new Color3f(0.5F, 0.5F, 0F), 
		new Color3f(0.0F, 0.5F, 0.5F), 
		new Color3f(0.5F, 0.5F, 0.5F)
	};

	BranchGroup createTransBranchGroup;
	BranchGroup line_branch_group;
	BranchGroup surface_branch_group;

	private Color3f black_color = new Color3f(0.0F, 0.0F, 0.0F);
	private Color3f white_color = new Color3f(1.0F, 1.0F, 1.0F);
	private Vector<point> point_list;
	private PointArray la;

	class point
	{

		double x;
		double y;
		double z;
		byte value;

		point(double x, double y, double z, 
				byte value)
		{
			this.x = x;
			this.y = y;
			this.z = z;
			this.value = value;
		}
	}


	public void createSimpleUniverse()
	{
		sceneGraph = new BranchGroup();
		trg = new TransformGroup();
		trg.setCapability(14);
		trg.setCapability(13);
		trg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		createTrans();
		sceneGraph.addChild(trg);
		su = new SimpleUniverse(canvas3D);
		ViewingPlatform viewingPlatform = su.getViewingPlatform();
		OrbitBehavior orbit = new OrbitBehavior(canvas3D, 112);
		BoundingSphere bounds = new BoundingSphere(new Point3d(0.0D, 0.0D, 0.0D), 10D);
		orbit.setSchedulingBounds(bounds);
		viewingPlatform.setViewPlatformBehavior(orbit);
		viewingPlatform.setNominalViewingTransform();
		Background bk = new Background();
		bk.setApplicationBounds(bounds);
		sceneGraph.addChild(bk);
		su.addBranchGraph(sceneGraph);
	}

	public void drawBox(float x, float y, float z, int color)
	{
		TransparencyAttributes t_attr = new TransparencyAttributes(TransparencyAttributes.FASTEST, 0.3F);
		Appearance app = new Appearance();
		app.setTransparencyAttributes(t_attr);
		Material m = new Material();
		m.setEmissiveColor(colors[color]);
		app.setMaterial(m);
		Box box = new Box(cube_length, cube_length, cube_length, app);

		Transform3D t2 = new Transform3D();
		t2.set(new Vector3f(x - cube_length/2, y - cube_length/2, z - cube_length/2));
		TransformGroup tran2 = new TransformGroup(t2);
		tran2.addChild(box);
		BranchGroup b = new BranchGroup();
		b.setCapability(17);
		b.addChild(tran2);

		trg.addChild(b);
	}

	public void createTrans()
	{
		Point3f xyzpoint[] = 
		{
			new Point3f(0.0F, 0.0F, 0.0F), new Point3f(10F, 0.0F, 0.0F), 
			new Point3f(0.0F, 0.0F, 0.0F), new Point3f(0.0F, 10F, 0.0F), 
			new Point3f(0.0F, 0.0F, 0.0F), new Point3f(0.0F, 0.0F, 10F)
		};

		LineArray axl = new LineArray(xyzpoint.length, 5);
		axl.setCoordinates(0, xyzpoint);
		for(int i = 0; i < 6; i++)
			axl.setColor(i, axes_colors[i/2]);

		Shape3D line = new Shape3D(axl, new Appearance());
		createTransBranchGroup = new BranchGroup();
		line_branch_group = new BranchGroup();
		line_branch_group.addChild(line);
		createTransBranchGroup.addChild(line_branch_group);
		createTransBranchGroup.setCapability(17);
		trg.addChild(createTransBranchGroup);

		Matrix3d rotY = new Matrix3d(
				Math.cos(Math.PI/6),0,-Math.sin(Math.PI/6),
				0, 1 , 0,
				Math.sin(Math.PI/6), 0 , Math.cos(Math.PI/6)
				);
		Matrix3d rotX = new Matrix3d(
				1,0,0,
				0, Math.cos(Math.PI/6), -Math.sin(Math.PI/6),
				0, Math.sin(Math.PI/6), Math.cos(Math.PI/6)
				);
		rotX.mul(rotY);
		Transform3D viewPos = new Transform3D();
		viewPos.setRotation(rotX);
		trg.setTransform(viewPos);
	}

	public void layoutComponents()
	{
		java.awt.GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
		input_panel = new InputPanel(this);

		canvas3D = new Canvas3D(config);
		this.getContentPane().add("Center", canvas3D);

		JPanel containPanel = new JPanel();
		containPanel.add(input_panel);
		this.getContentPane().add("East",containPanel);

		JLabel X = new JLabel("X:");
		JLabel Y = new JLabel("Y:");
		JLabel Z = new JLabel("Z:");
		xvalue = new JTextField("0.0");
		yvalue = new JTextField("0.0");
		zvalue = new JTextField("0.0");
		input_line = new JTextField("-t 2 -c 100");
		JButton button_enter = new JButton("Enter");
		JButton button_change = new JButton("Change");
		JButton button_run = new JButton("Run");
		JButton button_clear = new JButton("Clear");
		JButton button_view = new JButton("View");
		JPanel p = new JPanel();
		GridBagLayout gridbag = new GridBagLayout();
		p.setLayout(gridbag);
		GridBagConstraints c = new GridBagConstraints();
		c.fill = 2;
		c.gridy = 0;
		c.gridwidth = 1;
		c.weightx = 0.0D;
		gridbag.setConstraints(X, c);
		gridbag.setConstraints(Y, c);
		gridbag.setConstraints(Z, c);
		c.weightx = 1.0D;
		gridbag.setConstraints(button_enter, c);
		gridbag.setConstraints(button_view, c);
		c.gridwidth = 2;
		gridbag.setConstraints(xvalue, c);
		gridbag.setConstraints(yvalue, c);
		gridbag.setConstraints(zvalue, c);
		c.gridy = 1;
		gridbag.setConstraints(input_line, c);
		c.gridwidth = 3;
		gridbag.setConstraints(button_change, c);
		gridbag.setConstraints(button_run, c);
		gridbag.setConstraints(button_clear, c);
		p.add(X);
		p.add(xvalue);
		p.add(Y);
		p.add(yvalue);
		p.add(Z);
		p.add(zvalue);
		p.add(button_enter);
		p.add(button_view);
		p.add(button_change);
		p.add(button_run);
		p.add(button_clear);
		p.add(input_line);
		this.getContentPane().add(p, BorderLayout.SOUTH);

		button_change.addActionListener(new ActionListener() 
				{ public void actionPerformed(ActionEvent e)
				{ button_change_clicked(); } });

		button_enter.addActionListener(new ActionListener() 
				{ public void actionPerformed(ActionEvent e)
				{ button_enter_clicked(); }});

		button_clear.addActionListener(new ActionListener() 
				{ public void actionPerformed(ActionEvent e)
				{ button_clear_clicked(); }});

		button_run.addActionListener(new ActionListener()
				{ public void actionPerformed(ActionEvent e)
				{ button_run_clicked(input_line.getText()); }});

		button_view.addActionListener(new ActionListener() 
				{ public void actionPerformed(ActionEvent e)
				{ button_view_clicked(); }});
	}

	/**
	 * Set original color.
	 * Set Display format.
	 * Allocate space
	 */
	public svm_toy3d()
	{
		nowcolor = 0;
		point_list = new Vector<point>();
		layoutComponents();
		createSimpleUniverse();

		nf = NumberFormat.getInstance(Locale.US);
		nf.setMaximumFractionDigits(3);
		nf.setMinimumFractionDigits(3);
	}

	/**
	 * Only 3 classes of object allowed
	 */
	public void button_change_clicked()
	{
		nowcolor++;
		if(nowcolor > 2)
			nowcolor = 0;
	}

	/**
	 * set viewer back to origin
	 */
	public void button_view_clicked()
	{
		ViewingPlatform viewingPlatform = su.getViewingPlatform();
		viewingPlatform.setNominalViewingTransform();
	}

	/**
	 * enter a point from text input area with coordinate adjusted by some parameter.
	 */
	public void button_enter_clicked()
	{
		float xv = Float.parseFloat(xvalue.getText()) * coordinate_parameter;
		float yv = Float.parseFloat(yvalue.getText()) * coordinate_parameter;
		float zv = Float.parseFloat(zvalue.getText()) * coordinate_parameter;
		drawBox(xv, yv, zv, nowcolor);
		point p = new point(xv, yv, zv, nowcolor);
		point_list.addElement(p);
	}

	/**
	 * Add a point to point_list, and draw it
	 */
	public void inputFrameAdd(float xv, float yv, float zv)
	{
		xv = xv * coordinate_parameter;
		yv = yv * coordinate_parameter;
		zv = zv * coordinate_parameter;
		drawBox(xv, yv, zv, nowcolor);
		point p = new point(xv, yv, zv, nowcolor);
		point_list.addElement(p);
	}

	public void button_clear_clicked()
	{
		point_list.removeAllElements();
		ViewingPlatform viewingPlatform = su.getViewingPlatform();
		viewingPlatform.setNominalViewingTransform();
		trg.removeAllChildren();
		System.gc();
		createTrans();
	}

	public void setPosStatus(double x, double y, double z)
	{
		xvalue.setText(nf.format(x));
		yvalue.setText(nf.format(y));
		zvalue.setText(nf.format(z));
	}

	public void setPosZStatus(double z)
	{
		zvalue.setText(nf.format(z));
	}

	public void draw_surface(java.util.List surface_points, java.util.List points_color){
		//draw the surface
		la = new PointArray(surface_points.size(),PointArray.ALLOW_NORMAL_WRITE);
		la.setCapability(3);

		for(int i=0;i<surface_points.size();i++)
		{
			la.setCoordinate(i, (Point3f)surface_points.get(i));
			la.setColor(i,colors[((Integer)points_color.get(i)).intValue()]);
		}

		TransparencyAttributes t_attr = new TransparencyAttributes(TransparencyAttributes.FASTEST, 0.3F);
		Appearance app = new Appearance();
		app.setTransparencyAttributes(t_attr);
		Shape3D myshape = new Shape3D(la, app);
		//remove the original shape...
		trg.removeChild(createTransBranchGroup);
		createTransBranchGroup.removeChild(surface_branch_group);
		//remove complete...
		//add the original shape...
		surface_branch_group = new BranchGroup();
		surface_branch_group.addChild(myshape);
		createTransBranchGroup.addChild(surface_branch_group);
		trg.addChild(createTransBranchGroup);
		//add complete
	}

	void button_run_clicked(String args)
	{
		if(point_list.isEmpty())
			return;

		svm_parameter param = new svm_parameter();
		param.svm_type = 0;
		param.kernel_type = 2;
		param.degree = 3;
		param.gamma = 0.0D;
		param.coef0 = 0.0D;
		param.nu = 0.5D;
		param.cache_size = 40D;
		param.C = 1.0D;
		param.eps = 0.001D;
		param.p = 0.10000000000000001D;
		param.shrinking = 1;
		param.probability = 0;
		param.nr_weight = 0;
		param.weight_label = new int[0];
		param.weight = new double[0];
		StringTokenizer st = new StringTokenizer(args);
		String argv[] = new String[st.countTokens()];
		for(int i = 0; i < argv.length; i++)
			argv[i] = st.nextToken();

		for(int i = 0; i < argv.length; i++)
		{
			if(argv[i].charAt(0) != '-')
				break;
			i++;
			switch(argv[i - 1].charAt(1))
			{
				case 's':
					param.svm_type = atoi(argv[i]);
					break;

				case 't':
					param.kernel_type = atoi(argv[i]);
					break;

				case 'd':
					param.degree = atoi(argv[i]);
					break;

				case 'g':
					param.gamma = atof(argv[i]);
					break;

				case 'r':
					param.coef0 = atof(argv[i]);
					break;

				case 'n':
					param.nu = atof(argv[i]);
					break;

				case 'm':
					param.cache_size = atof(argv[i]);
					break;

				case 'c':
					param.C = atof(argv[i]);
					break;

				case 'e':
					param.eps = atof(argv[i]);
					break;

				case 'p':
					param.p = atof(argv[i]);
					break;

				case 'h':
					param.shrinking = atoi(argv[i]);
					break;

				case 'b':
					param.probability = atoi(argv[i]);
					break;

				case 'w':
					param.nr_weight++;
					int old[] = param.weight_label;
					param.weight_label = new int[param.nr_weight];
					System.arraycopy(old, 0, param.weight_label, 0, param.nr_weight - 1);

					param.weight = new double[param.nr_weight];
					System.arraycopy(old, 0, param.weight, 0, param.nr_weight - 1);
					param.weight_label[param.nr_weight - 1] = atoi(argv[i - 1].substring(2));
					param.weight[param.nr_weight - 1] = atof(argv[i]);
					break;

				case 'f':
				case 'i':
				case 'j':
				case 'k':
				case 'l':
				case 'o':
				case 'q':
				case 'u':
				case 'v':
				default:
					System.err.print("unknown option\n");
					break;
			}
		}

		svm_problem prob = new svm_problem();
		prob.l = point_list.size();
		prob.y = new double[prob.l];
		if(param.svm_type == 3 || param.svm_type == 4)
		{
			//set points for training
			if(param.gamma == 0.0D) param.gamma = 1D;
			prob.x = new svm_node[prob.l][2];
			for(int i = 0; i < prob.l; i++)
			{
				point p = point_list.elementAt(i);
				prob.x[i][0] = new svm_node();
				prob.x[i][0].index = 1;
				prob.x[i][0].value = p.x;
				prob.x[i][1] = new svm_node();
				prob.x[i][1].index = 2;
				prob.x[i][1].value = p.y;
				prob.y[i] = p.z;
			}
			//train
			libsvm.svm_model model = svm.svm_train(prob, param);
			//find margin points
			svm_node x[] = new svm_node[2];
			x[0] = new svm_node();
			x[1] = new svm_node();
			x[0].index = 1;
			x[1].index = 2;
			float[][] z = new float[100][100];

			ArrayList<Point3f> surface_points = new ArrayList<Point3f>();
			ArrayList<Integer> points_color = new ArrayList<Integer>();
			Point3f pt;

			for (int i = 0; i < max_point; i++)
			{
				for (int j = 0; j < max_point; j++)
				{
					x[0].value = ((float)(i - (max_point/2)) / ((float)max_point/2)) * coordinate_parameter;
					x[1].value = ((float)(j - (max_point/2)) / ((float)max_point/2)) * coordinate_parameter;
					z[i][j] = (float)(svm.svm_predict(model, x));

					pt = new Point3f(((float)(i - (max_point/2)) / ((float)max_point/2)) * coordinate_parameter, 
							((float)(j - (max_point/2)) / ((float)max_point/2)) * coordinate_parameter, z[i][j]);
					surface_points.add(pt);
					points_color.add(new Integer(0));
				}
			}
			draw_surface(surface_points,points_color);
		} else
		{
			//set points for training
			if(param.gamma == 0.0D)
				param.gamma = 0.5D;
			prob.x = new svm_node[prob.l][3];//3 is for dimension
			for(int i = 0; i < prob.l; i++)
			{
				point p = point_list.elementAt(i);
				prob.x[i][0] = new svm_node();
				prob.x[i][0].index = 1;
				prob.x[i][0].value = p.x;
				prob.x[i][1] = new svm_node();
				prob.x[i][1].index = 2;
				prob.x[i][1].value = p.y;
				prob.x[i][2] = new svm_node();
				prob.x[i][2].index = 3;
				prob.x[i][2].value = p.z;
				prob.y[i] = p.value;
			}
			//train
			libsvm.svm_model model = svm.svm_train(prob, param);
			//find margin points
			svm_node x[] = new svm_node[3];
			x[0] = new svm_node();
			x[1] = new svm_node();
			x[2] = new svm_node();
			x[0].index = 1;
			x[1].index = 2;
			x[2].index = 3;

			ArrayList<Point3f> surface_points = new ArrayList<Point3f>();
			ArrayList<Integer> points_color = new ArrayList<Integer>();
			Point3f pt;

			for(int i = 0; i < max_point; i++)
			{
				for(int j = 0; j < max_point; j++)
				{
					for(int k = 0; k < max_point; k++)
					{
						x[0].value = ((float)(i - max_point/2) / ((float)max_point/2) ) * coordinate_parameter;
						x[1].value = ((float)(j - max_point/2) / ((float)max_point/2) ) * coordinate_parameter;
						x[2].value = ((float)(k - max_point/2) / ((float)max_point/2) ) * coordinate_parameter;
						double d = svm.svm_predict(model, x);
						if(param.svm_type == 2 && d < 0.0D)
							d = 2D;

						surface[i][j][k] = (int)d;
					}

				}

			}

			for(int i = 1; i < max_point-1; i++)
			{
				for(int j = 1; j < max_point-1; j++)
				{
					for(int k = 1; k < max_point-1; k++)
					{
						if(( (surface[i][j][k]!=surface[i][j][k-1])
									|| (surface[i][j][k]!=surface[i][j-1][k])
									|| (surface[i][j][k]!=surface[i-1][j][k])
									|| (surface[i][j][k]!=surface[i][j][k+1])
									|| (surface[i][j][k]!=surface[i][j+1][k])
									|| (surface[i][j][k]!=surface[i+1][j][k]) ))

						{
							//count the number of points.
							pt = new Point3f(((float)(i - max_point/2) / ((float)max_point/2) ) * coordinate_parameter, 
									((float)(j - max_point/2) / ((float)max_point/2) ) * coordinate_parameter, 
									((float)(k - max_point/2) / ((float)max_point/2) ) * coordinate_parameter);
							surface_points.add(pt);
							points_color.add(new Integer(surface[i][j][k]));
						}
					}
				}

			}
			draw_surface(surface_points,points_color);
		}
	}

	private static double atof(String s)
	{
		return Double.valueOf(s).doubleValue();
	}

	private static int atoi(String s)
	{
		return Integer.parseInt(s);
	}

	public static void main(String args[])
	{
		java.awt.Frame frame = new MainFrame(new svm_toy3d(), 600, 600);
	}

}


